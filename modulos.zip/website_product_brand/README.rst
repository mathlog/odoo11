alt: License: AGPL-3

Website Product Brand
==================================

Description
-----------
Allows to use product brands as filtering for products in website.
This Module depends on product_brand module
-https://github.com/OCA/product-attribute/tree/10.0/product_brand

Bug Tracker
===========

Credits
=======

Contributors
------------

* Jay Vora <jay.vora@serpentcs.com>

